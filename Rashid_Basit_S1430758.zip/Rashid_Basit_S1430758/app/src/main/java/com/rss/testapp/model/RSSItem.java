//Basit Rashid, S1430758
package com.rss.testapp.model;

import android.os.Parcel;
import android.os.Parcelable;

public class RSSItem implements Parcelable {
    protected RSSItem(Parcel in) {
        title = in.readString();
        link = in.readString();
        description = in.readString();
        pubdate = in.readString();
        guid = in.readString();
    }

    public static final Creator<RSSItem> CREATOR = new Creator<RSSItem>() {
        @Override
        public RSSItem createFromParcel(Parcel in) {
            return new RSSItem(in);
        }

        @Override
        public RSSItem[] newArray(int size) {
            return new RSSItem[size];
        }
    };

    public void setTitle(String title) {
        this.title = title;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setPubdate(String pubdate) {
        this.pubdate = pubdate;
    }

    public void setGuid(String guid) {
        this.guid = guid;
    }

    public String title = "";
    public String link = "";
    public String description = "";
    public String pubdate = "";
    public String guid = "";

    public RSSItem() {

    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(title);
        dest.writeString(link);
        dest.writeString(description);
        dest.writeString(pubdate);
        dest.writeString(guid);
    }
}
