//Basit Rashid, S1430758
package com.rss.testapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.core.util.Pair;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.app.SearchManager;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.datepicker.MaterialDatePicker;
import com.google.android.material.datepicker.MaterialPickerOnPositiveButtonClickListener;
import com.rss.testapp.model.RSSItem;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import static com.google.android.material.datepicker.MaterialDatePicker.Builder.dateRangePicker;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private Button startButton;
    private Button worksButton;
    private Button planButton;
    private RecyclerView mRecyclerView;
    private ProgressBar mProgressBar;
    private SearchView searchView;
    // Traffic Scotland URLs
    private String worksSource = "https://trafficscotland.org/rss/feeds/roadworks.aspx";
    private String planSource = "https://trafficscotland.org/rss/feeds/plannedroadworks.aspx";
    private String urlSource = "https://trafficscotland.org/rss/feeds/currentincidents.aspx";

    private ArrayList<RSSItem> mFeedModelList;
    private RssFeedListAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        startButton = findViewById(R.id.startButton);
        startButton.setOnClickListener(this);
        worksButton = findViewById(R.id.worksButton);
        worksButton.setOnClickListener(this);
        planButton = findViewById(R.id.planButton);
        planButton.setOnClickListener(this);
        mRecyclerView = findViewById(R.id.recyclerView);
        mProgressBar = findViewById(R.id.progressBar);
        adapter = new RssFeedListAdapter();
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        mRecyclerView.setAdapter(adapter);
        findViewById(R.id.clearButton).setOnClickListener(this);
        if (savedInstanceState != null) {
            mFeedModelList = savedInstanceState.getParcelableArrayList("list");
            if (mFeedModelList != null) {
                adapter.updateFeeds(mFeedModelList);
            }
        }
    }

    // This is called before the activity is destroyed
    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putParcelableArrayList("list", mFeedModelList);
    }

    public void onClick(View v) {

/*
Ok the problem is every time you click on button any button onClick method is called
your old approach was this
startProgress();
worksProgress();
planProgress();
This means everytime you click on anything all these methods will execute
Hence causing everything to show up

WHAT YOU SHOULD BE DOING
every button has an id
use switch statements to differentiate which button is called
and then called the respective method hope that helps
*/
        switch (v.getId()) {

            case R.id.startButton:
                startProgress();
                break;
            case R.id.worksButton:
                worksProgress();
                break;
            case R.id.planButton:
                planProgress();
                break;
            case R.id.clearButton:
                findViewById(R.id.layout_buttons).setVisibility(View.VISIBLE);
                findViewById(R.id.layout_filter).setVisibility(View.GONE);
                adapter.updateFeeds(mFeedModelList);
                break;
        }


    }

    public void startProgress() {
        // Run network access on a separate thread;
        new FetchFeedTask().execute(urlSource);

    } //

    public void worksProgress() {
        // Run network access on a separate thread;
        new FetchFeedTask().execute(worksSource);
    } //

    public void planProgress() {
        new FetchFeedTask().execute(planSource);
    }

    // Parse the url inputStream to displayable list of Feeds
    public ArrayList<RSSItem> parseFeed(InputStream inputStream) throws XmlPullParserException, IOException {
        String text = "";
        RSSItem item = new RSSItem();
        ArrayList<RSSItem> items = new ArrayList<>();
        try {
            // init the XmlPullParser
            XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
            factory.setNamespaceAware(true);
            XmlPullParser parser = factory.newPullParser();
            parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false);
            parser.setInput(inputStream, null);

            int eventType = parser.getEventType();
            while (eventType != XmlPullParser.END_DOCUMENT) {
                // Get XML Tag Name
                String name = parser.getName();
                switch (eventType) {
                    // If event type is Start document break the switch statement because XML Tag name is Null
                    case XmlPullParser.START_DOCUMENT:
                        break;
                    case XmlPullParser.START_TAG:
                        // If XML stater Tag of item init RSSItem object
                        if (name.equals("item"))
                            item = new RSSItem();
                        break;
                    // If event type is Text means data b/w XML starting and ending Tag
                    case XmlPullParser.TEXT:
                        text = parser.getText();
                        break;
                    // If event type is XML Tag End save data
                    case XmlPullParser.END_TAG:
                        switch (name) {
                            case "title": // If XML Tag Name is title set value to item
                                item.setTitle(text);
                                break;
                            case "description": // If XML Tag Name is description set value to item
                                item.setDescription(text);
                                break;
                            case "link": // If XML Tag Name is link set value to item
                                item.setLink(text);
                                break;
                            case "pubDate": // If XML Tag Name is pubDate set value to item
                                item.setPubdate(text);
                                break;
                            case "item": // If XML Tag Name is title add item to  list of item
                                items.add(item);
                                break;
                        }
                        break;
                }
                // Get event type and move XMLPullParser to next
                eventType = parser.next();
            }
            return items;
        } finally {
            // Close InputStream after parsing to avoid memory leaks
            inputStream.close();
        }
    }

    // Make network call and long running task on separate thread to avoid
    @SuppressLint("StaticFieldLeak")
    private class FetchFeedTask extends AsyncTask<String, Void, Boolean> {

        @Override
        protected void onPreExecute() {
            // Display Progress and Hide RecycleView
            setRefreshing(true);
        }

        @Override
        protected Boolean doInBackground(String... strings) {
            URL aurl;
            URLConnection yc;
            try {
                if (!strings[0].startsWith("http://") && !strings[0].startsWith("https://"))
                    strings[0] = "http://" + strings[0];

                aurl = new URL(strings[0]);
                yc = aurl.openConnection();
                InputStream inputStream = yc.getInputStream();
//                InputStream inputStream = getAssets().open("roadworks.xml");

                mFeedModelList = parseFeed(inputStream);
                return true;
            } catch (IOException | XmlPullParserException e) {
                Log.e("MainActivity", "Error", e);
            }
            return false;
        }

        @Override
        protected void onPostExecute(Boolean success) {
            // Display RecycleView and Hide Progress
            setRefreshing(false);
            // Check if no error occurs
            if (success) {
                // Fill RecyclerView
                adapter.updateFeeds(mFeedModelList);
            } else {
                Toast.makeText(MainActivity.this,
                        "Enter a valid Rss feed url",
                        Toast.LENGTH_LONG).show();
            }
        }

    }

    private void setRefreshing(boolean b) {
        startButton.setEnabled(!b);
        planButton.setEnabled(!b);
        worksButton.setEnabled(!b);
        if (b) {
            mProgressBar.setVisibility(View.VISIBLE);
            mRecyclerView.setVisibility(View.GONE);
        } else {
            mProgressBar.setVisibility(View.GONE);
            mRecyclerView.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);

        // Associate searchable configuration with the SearchView
        SearchManager searchManager = (SearchManager) getSystemService(Context.SEARCH_SERVICE);
        searchView = (SearchView) menu.findItem(R.id.action_search)
                .getActionView();
        searchView.setSearchableInfo(searchManager
                .getSearchableInfo(getComponentName()));
        searchView.setMaxWidth(Integer.MAX_VALUE);
        searchView.setQueryHint(getString(R.string.action_search));
        searchView.setOnSearchClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mFeedModelList == null) {
                    if (!searchView.isIconified()) {
                        searchView.setIconified(true);
                    }
                }
            }
        });
        // listening to search query text change
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                // filter recycler view when query submitted
                if (mFeedModelList != null && !mFeedModelList.isEmpty())
                    adapter.getFilter().filter(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String query) {
                // filter recycler view when text is changed
                if (mFeedModelList != null && !mFeedModelList.isEmpty())
                    adapter.getFilter().filter(query);
                return false;
            }
        });
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_search) {
            return true;
        } else if (id == R.id.action_date) {
            if (mFeedModelList != null && !mFeedModelList.isEmpty()) {
                //Date Picker
                MaterialDatePicker.Builder builder = MaterialDatePicker.Builder.dateRangePicker();
                MaterialDatePicker picker = builder
                        .build();
                picker.show(getSupportFragmentManager(), picker.toString());
                picker.addOnPositiveButtonClickListener(new MaterialPickerOnPositiveButtonClickListener<Pair<Long, Long>>() {
                    @Override
                    public void onPositiveButtonClick(Pair<Long, Long> selection) {
                        if (selection.first != null && selection.second != null) {
                            List<RSSItem> filteredList = new ArrayList<>();
                            DateFormat dateFormat = new SimpleDateFormat("E, dd MMM yyyy", Locale.US);
                            for (RSSItem row : mFeedModelList) {
                                try {
                                    Date date = dateFormat.parse(row.pubdate.replace(" 00:00:00 GMT", ""));
                                    if (date != null && (date.getTime() >= selection.first && date.getTime() <= selection.second)) {
                                        filteredList.add(row);
                                    }
                                } catch (ParseException pe) {
                                    // handle the failure
                                    pe.printStackTrace();
                                }
                                StringBuilder builder1 = new StringBuilder();
                                builder1.append("From : ");
                                builder1.append(dateFormat.format(new Date(selection.first)));
                                builder1.append("\n");
                                builder1.append("To : ");
                                builder1.append(dateFormat.format(new Date(selection.second)));
                                ((TextView) findViewById(R.id.filter_date)).setText(
                                        builder1
                                );
                                findViewById(R.id.layout_buttons).setVisibility(View.GONE);
                                findViewById(R.id.layout_filter).setVisibility(View.VISIBLE);
                                adapter.updateFeeds(filteredList);
                            }
                        }
                    }
                });
            }
//            Button button = picker.getView().findViewById(R.id.confirm_button);
//            if (button != null) {
//                button.setText("Apply");
//            }
            return true;
        } else if (id == R.id.action_exit) {
            finish();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        // close search view on back button pressed
        if (!searchView.isIconified()) {
            searchView.setIconified(true);
            return;
        }
        super.onBackPressed();
    }
} // End of MainActivity
